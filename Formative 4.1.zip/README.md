# This App was made for Yoobee Colleges Module 4 CMS Formative 4.1

# .env.development.local did not work on my computer. create the file for to use 'baseUrl' (or dont).


This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## How to start the app

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.